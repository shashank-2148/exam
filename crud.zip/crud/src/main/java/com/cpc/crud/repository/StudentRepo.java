package com.cpc.crud.repository;

import org.springframework.data.repository.CrudRepository;

import com.cpc.crud.model.Student;

public interface StudentRepo extends CrudRepository<Student, Integer> {

}
