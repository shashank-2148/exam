package com.mongo.mongo.Model;

import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.persistence.Id;

@Document("tblcust")

public class Customer {
	


	@Id
	private int cid;
	private String name;
	private String age;
	private String genter;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGenter() {
		return genter;
	}
	public void setGenter(String genter) {
		this.genter = genter;
	}
	@Override
	public String toString() {
		return "Student [cid=" + cid + ", name=" + name + ", age=" + age + ", genter=" + genter + "]";
	}
	
	


}
