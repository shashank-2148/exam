package com.mongo.mongo.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mongo.mongo.Model.Customer;

public interface CustRepo extends MongoRepository<Customer, Integer>{

}
