package com.mongo.mongo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mongo.mongo.Model.Customer;
import com.mongo.mongo.Repository.CustRepo;

@RestController
public class StudentController {
	@Autowired
	CustRepo custrepo;
	
	@RequestMapping("/addCust")
	public String addCust(@RequestBody Customer customer) {
		custrepo.save(customer);
		return "inserted successfully";
	}
	
	@GetMapping("/getCust")
	public List<Customer>getCust(){
		return custrepo.findAll();
	}
	
	@RequestMapping("/delCust/{cid}")
	public String delCust(@PathVariable int cid) {
		custrepo.deleteById(cid);
		return "deleted";
	}
	
	

}
