package com.cpcapi.cpcapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpcapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpcapiApplication.class, args);
	}

}
