package com.cpcapi.cpcapi.Repository;

import org.springframework.data.repository.CrudRepository;

import com.cpcapi.cpcapi.Model.Employee;

public interface EmpRepo extends CrudRepository<Employee, Integer> {

}
