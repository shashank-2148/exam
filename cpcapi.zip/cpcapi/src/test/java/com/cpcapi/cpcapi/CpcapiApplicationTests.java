package com.cpcapi.cpcapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpcapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
